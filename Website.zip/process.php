<?php
session_start();
  $key = $_GET['key'];
  $value=	$_SESSION['VALUE'];
  $table="";
 // echo $key;
/**  
	this is for the search in which table it has to search
**/
	  if($value==1)
	  $table="index_text";
	  else if($value==2)
	  $table="index_name";
	  if($value==3)
	  $table="index_hash";
	  else if($value==4)
	  $table="index_screen";
	  
/**
	now the query proessing 
**/
	if (strpos($key,' ') == false)
	{
    
	  $con = mysqli_connect('127.0.0.1','root','','informationretrival');
	  $query = "select distinct text from $table where text like '%$key%' LIMIT 0,10";
	  //echo $query;
	  $res = mysqli_query($con,$query);
	  $ans = "";
	  while ($row = mysqli_fetch_array($res)) {
		$ans.= $row['text'] . "<br />";
	  }
		echo $ans;     	
	}
	else
	{
		$key1 = explode(" ", $key);
		$con = mysqli_connect('127.0.0.1','root','','informationretrival');
	  	for($k=0;$k<sizeof($key1);$k++)
		{
		$query1 = "select text from $table where text like '%$key1[$k]%' LIMIT 0,10";
		  //echo $query;
		  $res1 = mysqli_query($con,$query1);
		  $ans1 = "";
		  while ($row = mysqli_fetch_array($res1)) {
			$ans1.= $row['text'] . "<br />";
		  }
		echo $ans1;
		}
	}
  
  
  mysqli_close($con);
?>