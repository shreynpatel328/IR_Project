<?php 
	error_reporting(0);
	session_start();
	$search=$_GET['search']; // get the value of search from the text box from the search.html
	$search1 = explode(" ", $search); //check if it contains more than one word
   // echo $search;
	/***

		The function  is for the highligting the search word

	***/
	$global4print=array();
	function highlightkeyword($str, $search)
	{
		$search1 = explode(" ", $search);
		for($k=0;$k<sizeof($search1);$k++)
		{
		
		$highlightcolor = "#2BB5D8";
		$occurrences = substr_count(strtolower($str), strtolower($search1[$k]));
		$newstring = $str;
		$match = array();

		for ($i=0;$i<$occurrences;$i++) 
		{
			$match[$i] = stripos($str, $search1[$k], $i);
			$match[$i] = substr($str, $match[$i], strlen($search1[$k]));
			$newstring = str_replace($match[$i], '[#]'.$match[$i].'[@]', strip_tags($newstring));
		}

		$newstring = str_replace('[#]', '<span style="color: '.$highlightcolor.';">', $newstring);
		$newstring = str_replace('[@]', '</span>', $newstring);
		return $newstring;
	
		}
	}

	/**
		The function ends here
	**/

	/****

		The if is for if the search is one word  and in the else we take care if the search contains more than one word

	****/

	if (strpos($search,' ') == false)
	{
		$con = mysqli_connect('127.0.0.1','root','','informationretrival');
		$query = "select * from index_name where text='$search'";
		//echo $query;
		$res = mysqli_query($con,$query);					
		$ans = "";
		//echo $row = mysqli_fetch_array($res);
		while ($row = mysqli_fetch_array($res)) 
		{
			
			$ans.= $row['index'];
			//echo "goijng in";

			/**
				we have tweets as : in btw so we explode it with :
			**/

			$id = explode(":", $ans);
			//var_dump($id);

			for($k=0;$k<sizeof($id);$k++)
			{	 
				
				array_push($global4print, $id[$k]);
				/*$con = mysqli_connect('127.0.0.1','root','','informationretrival');
				$query = "select * from tweet where id='$id[$k]'";
				//echo $query;
				$res = mysqli_query($con,$query);					
				$ans = "";
				while ($row = mysqli_fetch_array($res)) 
				{
					//echo "going in";
					$my_id= $row['id'];
					$text= $row['text'];
					$name= $row['name'];
				    $screen= $row['screen_name'];
					$followers= $row['followers'];
					$friends= $row['friends'];
					$re_name=$row['re_name'];
					$re_screen=$row['re_screen'];
				if(strpos($text,$search) == true)
				{
					echo highlightkeyword("TweetCredits ", "TweetCredits ")."<br>";
				//	echo $my_id." ".highlightkeyword($text, $search)."   Name:".$name."  ".$followers." ".$frineds." Screen_name   ".$screen."<br>"." re Tweet credits"."   Name:".$re_name." Screen_name   ".$re_screen."<br>";
					echo "My Tweet ID:  ".$my_id."<br>";
					echo "Tweet:  ".highlightkeyword($text, $search)."<br>";
					echo "Name:  ".$name."<br>";
					echo "Screen Name:  ".$screen."<br>";
					echo "Followers:  ".$followers."<br>";
					echo "Friends:  ".$friends."<br>";
					echo "Tweet Time:  ".$time = $row['tweet_time'];
					echo "<br>";
					if($re_name!=" " && $re_screen!=" ")
					{	
						echo highlightkeyword("RETweetCredits", "RETweetCredits")."<br>";
						echo "Name:  ".$re_name."<br>";
						echo "Screen Name:  ".$re_screen."<br>";
					}
					//echo "<br>";echo "<br>";
				
				 }
				}*/
			}

		}
			$global4print = array_unique($global4print);
	//	var_dump($global4print);
	}

	else
	{

		$search1 = explode(" ", $search);
		$z=0;
		$array = array();
		$con = mysqli_connect('127.0.0.1','root','','informationretrival');
		for($k=0;$k<sizeof($search1);$k++)
		{	 
			$query = "select * from index_name where text='$search1[$k]'";
			$res = mysqli_query($con,$query);					
			$ans = "";
			while ($row = mysqli_fetch_array($res)) 
			{

				$ans.= $row['index'];  
				//echo $ans;   // get the ids of the tweets
				$id = explode(":", $ans); 
				//echo "<br>";
				
				//echo sizeof($id);	// explode the ids on the :
				$values = array();        // making the double dimensional array to store the ids
				for($i=0;$i<sizeof($id);$i++)
				{
					array_push($values, $id[$i]);	 // pusshing the values to double dimensional array
				}  
				
				   // pushing array to array to make it double dimensional 

			}
			//var_dump($values);
			//echo "<br>";
//echo "<br>";
//echo "<br>";

				array_push($array, $values);
		}
			//var_dump($array);   // $ array contains all the ids of the all the words in the query. This is a double dimensional array because all the words on the x axis and the y axis will be the all the ids
			//var_dump(array_intersect($array[0], $array[1]));

		$result= array_reduce(array_slice($array, 0, -1), 'array_intersect', end($array));   // finding the intersection of the results if the ids are common so that wwe can rank them higher
		
		//sort($array);
		$result = array_values($result);
		//var_dump($result);
		//for($i=0;$i<sizeof($result);$i++)
		//	echo $result[$i]. "<br />";
		$time = array();
		
		if(sizeof($result)>0)   // this if will execute if the the intersection results is greater than 0 means we have intersection results
		{
			$sorting =array();
			/***
			this is for printing the first the intersection reults 
			**/
			for($k=0;$k<sizeof($result);$k++)
			{	 
				// echo "going in";
				$con = mysqli_connect('127.0.0.1','root','','informationretrival');
				$query = "select * from tweet where id='$result[$k]'";
				//echo $query;
				//echo $query;
				$res = mysqli_query($con,$query);					
				
				while ($row = mysqli_fetch_array($res)) 
				{
					/***
					This is to get the time in the correct order so we are trying to split the time in the perfect order so we can sort 
					***/
					$time = $row['tweet_time'];
					$time1 = explode(" ", $time);
					//for($i=0;$i<sizeof($time1);$i++)
					//echo $i." ".$time1[$i]. "<br />";
					$values = array();        // making the double dimensional array to store the ids
					array_push($values, $time1[1]);	 // pusshing the values to double dimensional array
					array_push($values, $time1[2]);
					$split=explode(":", $time1[3]);
					//for($i=0;$i<sizeof($split);$i++)
					//echo $i." ".$split[$i]. "<br />";
					array_push($values, $split[0]);
					array_push($values, $split[1]);
					array_push($values, $split[2]);
					
					//var_dump($values);
				}
				array_push($sorting, $values);  /// the array variable sorting is a double dimensional array with the array valiues (all the times)  
			}
			$cominedDate=array();   // declaring this array for storing the time in a certain order
			for($i=0;$i<sizeof($result);$i++)
			{
			     
				$combine="2015-".$sorting[$i][0]."-".$sorting[$i][1]." ".$sorting[$i][2].":".$sorting[$i][3].":".$sorting[$i][4];
				$c=0;
				//echo $combine;
				array_push($cominedDate, $combine);
			}
			
			arsort($cominedDate);			
			//echo "<br>"; 
			$cominedDate = array_unique($cominedDate);
			foreach ($cominedDate as $key => $val) 
			{
				//echo $resultSingle[$key]."   ";
				array_push($global4print, $result[$key]);
				/*
				$con = mysqli_connect('127.0.0.1','root','','informationretrival');
				$query = "select * from tweet where id='$result[$key]'";
				//echo $query;
				$res = mysqli_query($con,$query);		
				//echo "dateTimecobine[" . $key . "] = " . $val . "<br>";
				$row = mysqli_fetch_array($res);
				$my_id= $row['id'];
				$text= $row['text'];
				$name= $row['name'];
				$screen= $row['screen_name'];
				$followers= $row['followers'];
				$friends= $row['friends'];
				$re_name=$row['re_name'];
				$re_screen=$row['re_screen'];
				$time = $row['tweet_time'];
				
				//echo $my_id." ".highlightkeyword($text, $search)." ".$name."  ".$followers." ".$frineds."<br>";
				echo highlightkeyword("TweetCredits ", "TweetCredits ")."<br>";
			//	echo $my_id." ".highlightkeyword($text, $search)."   Name:".$name."  ".$followers." ".$frineds." Screen_name   ".$screen."<br>"." re Tweet credits"."   Name:".$re_name." Screen_name   ".$re_screen."<br>";
				echo "My Tweet ID:  ".$my_id."<br>";
				echo "Tweet:  ".highlightkeyword($text, $search)."<br>";
				echo "Name:  ".$name."<br>";
				echo "Screen Name:  ".$screen."<br>";
				echo "Followers:  ".$followers."<br>";
				echo "Friends:  ".$friends."<br>";
				echo "Tweet Time:  ".$time = $row['tweet_time'];
				echo "<br>";
				if($re_name!=" " && $re_screen!=" ")
				{	
					echo highlightkeyword("RETweetCredits", "RETweetCredits")."<br>";
					echo "Name:  ".$re_name."<br>";
					echo "Screen Name:  ".$re_screen."<br>";
				}
				echo "<br>";echo "<br>";
				*/
			}
			/*****
			The printing of the intersection results is done till here now take care of the rest of the reults 
			*****/
			/**
			the reults of the intersection is in the reults ka array 
			Now have to have to difference it with the originalk set so thta we cn get the results 
			Now getting the time 
			**/
			//echo "This is wat i m chgeckoing ";
			//var_dump($result);
			//var_dump($array);
			
			/***  

			HERE THE DIFFERENCE IS CALCULATED HERE AND THEN FOR THAT TIME IS TAKEN IN DOUBLE DIMENSIONAL ARRAY THEN MADE IN PROPER FORMAT THEN GET THE QUERY AND DISPLAY
			
			****/			
			
			$result4diff=array_reduce($array, 'array_merge', array());  /// converting the original array which is double dimensional arary to single dimension for the difference
			//var_dump($result4diff);
			$resultAfterDiff = array_diff($result4diff, $result);
			//var_dump($resultAfterDiff);
			$resultAfterDiff = array_values($resultAfterDiff);
			$sorting =array();
			
			for($k=0;$k<sizeof($resultAfterDiff);$k++)
			{	 
				// echo "going in";
				$con = mysqli_connect('127.0.0.1','root','','informationretrival');
				$query = "select * from tweet where id='$resultAfterDiff[$k]'";
				//echo $query;
				$res = mysqli_query($con,$query);					
				$ans = "";
				while ($row = mysqli_fetch_array($res)) 
				{
					/***
					This is to get the time in the correct order so we are trying to split the time in the perfect order so we can sort 
					***/
					$time = $row['tweet_time'];
					$time1 = explode(" ", $time);
					//for($i=0;$i<sizeof($time1);$i++)
					//echo $i." ".$time1[$i]. "<br />";
					$values = array();        // making the double dimensional array to store the ids
					array_push($values, $time1[1]);	 // pusshing the values to double dimensional array
					array_push($values, $time1[2]);
					$split=explode(":", $time1[3]);
					//for($i=0;$i<sizeof($split);$i++)
					//echo $i." ".$split[$i]. "<br />";
					array_push($values, $split[0]);
					array_push($values, $split[1]);
					array_push($values, $split[2]);
					
					//var_dump($values);
				}
				array_push($sorting, $values);  /// the array variable sorting is a double dimensional array with the array valiues (all the times)  
			}
			$cominedDate=array();   // declaring this array for storing the time in a certain order
			for($i=0;$i<sizeof($resultAfterDiff);$i++)
			{
			     
				$combine="2015-".$sorting[$i][0]."-".$sorting[$i][1]." ".$sorting[$i][2].":".$sorting[$i][3].":".$sorting[$i][4];
				$c=0;
				//echo $combine;
				array_push($cominedDate, $combine);
			}
			
			arsort($cominedDate);			
			//echo "<br>"; 
			$cominedDate = array_unique($cominedDate);
			
			foreach ($cominedDate as $key => $val) 
			{
				array_push($global4print,$resultAfterDiff[$key]);
				/*
				//echo $resultSingle[$key]."   ";
				$con = mysqli_connect('127.0.0.1','root','','informationretrival');
				$query = "select * from tweet where id='$resultAfterDiff[$key]'";
				//echo $query;
				$res = mysqli_query($con,$query);		
				//echo "dateTimecobine[" . $key . "] = " . $val . "<br>";
				$row = mysqli_fetch_array($res);
				$my_id= $row['id'];
				$text= $row['text'];
				$name= $row['name'];
				$screen= $row['screen_name'];
				$followers= $row['followers'];
				$friends= $row['friends'];
				$re_name=$row['re_name'];
				$re_screen=$row['re_screen'];
				$time = $row['tweet_time'];
				
				//echo $my_id." ".highlightkeyword($text, $search)." ".$name."  ".$followers." ".$frineds."<br>";
				echo highlightkeyword("TweetCredits ", "TweetCredits ")."<br>";
			//	echo $my_id." ".highlightkeyword($text, $search)."   Name:".$name."  ".$followers." ".$frineds." Screen_name   ".$screen."<br>"." re Tweet credits"."   Name:".$re_name." Screen_name   ".$re_screen."<br>";
				echo "My Tweet ID:  ".$my_id."<br>";
				echo "Tweet:  ".highlightkeyword($text, $search)."<br>";
				echo "Name:  ".$name."<br>";
				echo "Screen Name:  ".$screen."<br>";
				echo "Followers:  ".$followers."<br>";
				echo "Friends:  ".$friends."<br>";
				echo "Tweet Time:  ".$time = $row['tweet_time'];
				echo "<br>";
				if($re_name!=" " && $re_screen!=" ")
				{	
					echo highlightkeyword("RETweetCredits", "RETweetCredits")."<br>";
					echo "Name:  ".$re_name."<br>";
					echo "Screen Name:  ".$re_screen."<br>";
				}
				echo "<br>";echo "<br>";*/
			}
		
		}
		else /// if there is no intersection of the ids the this else will execute
		{
			
			$sorting =array();
			$resultSingle=array_reduce($array, 'array_merge', array()); // converting the double dimensional array to single dimensional array. This we are doing coz we are want all the ids times, so that we can sort it descending order 
			//for($i=0;$i<sizeof($resultSingle);$i++)
			//echo $i."  ".$resultSingle[$i]. "<br />";
			$resultSingle = array_values($resultSingle);
			for($k=0;$k<sizeof($resultSingle);$k++)
			{	 
				// echo "going in";
				$con = mysqli_connect('127.0.0.1','root','','informationretrival');
				$query = "select * from tweet where id='$resultSingle[$k]'";
				//echo $query;
				$res = mysqli_query($con,$query);					
				while ($row = mysqli_fetch_array($res)) 
				{
					$time = $row['tweet_time'];
					//echo $my_id." ".highlightkeyword($text, $search)." ".$name."  ".$followers." ".$frineds."<br>";
			
					/***
					This is to get the time in the correct order so we are trying to split the time in the perfect order so we can sort 
					***/
					
					$time1 = explode(" ", $time);
					//for($i=0;$i<sizeof($time1);$i++)
					//echo $i." ".$time1[$i]. "<br />";
					$values = array();        // making the double dimensional array to store the ids
					array_push($values, $time1[1]);	 // pusshing the values to double dimensional array
					array_push($values, $time1[2]);
					$split=explode(":", $time1[3]);
					//for($i=0;$i<sizeof($split);$i++)
					//echo $i." ".$split[$i]. "<br />";
					array_push($values, $split[0]);
					array_push($values, $split[1]);
					array_push($values, $split[2]);
					
				//	var_dump($values);
				}
				array_push($sorting, $values);  /// the array variable sorting is a double dimensional array with the array valiues (all the times)
			}
			//var_dump($sorting);
			
			$cominedDate=array();   // declaring this array for storing the time in a certain order
			for($i=0;$i<sizeof($resultSingle);$i++)
			{
			     
				$combine="2015-".$sorting[$i][0]."-".$sorting[$i][1]." ".$sorting[$i][2].":".$sorting[$i][3].":".$sorting[$i][4];
				$c=0;
				//echo $combine;
				array_push($cominedDate, $combine);

			}
			//var_dump($dateTimecobine);
			arsort($cominedDate);
			//echo "this is for no interscetion";
			//var_dump($cominedDate);// sorting the array in the descending order 
			//echo "<br>"; 
			//var_dump($resultSingle);
			
			
			/***
			    Printing the array cominedDate and relating to the single dimensional index fields 
			***/
			$cominedDate = array_unique($cominedDate);
			foreach ($cominedDate as $key => $val) 
			{
				//echo $resultSingle[$key]."   ";
				array_push($global4print,$resultSingle[$key]);
				/*
				$con = mysqli_connect('127.0.0.1','root','','informationretrival');
				$query = "select * from tweet where id='$resultSingle[$key]'";
				//echo $query;
				$res = mysqli_query($con,$query);		
				//echo "dateTimecobine[" . $key . "] = " . $val . "<br>";
				$row = mysqli_fetch_array($res);
				$my_id= $row['id'];
				$text= $row['text'];
				$name= $row['name'];
				$screen= $row['screen_name'];
				$followers= $row['followers'];
				$friends= $row['friends'];
				$re_name=$row['re_name'];
				$re_screen=$row['re_screen'];
				$time = $row['tweet_time'];
				
				//echo $my_id." ".highlightkeyword($text, $search)." ".$name."  ".$followers." ".$frineds."<br>";
				echo highlightkeyword("TweetCredits ", "TweetCredits ")."<br>";
			//	echo $my_id." ".highlightkeyword($text, $search)."   Name:".$name."  ".$followers." ".$frineds." Screen_name   ".$screen."<br>"." re Tweet credits"."   Name:".$re_name." Screen_name   ".$re_screen."<br>";
				echo "My Tweet ID:  ".$my_id."<br>";
				echo "Tweet:  ".highlightkeyword($text, $search)."<br>";
				
				echo "Name:  ".$name."<br>";
				echo "Screen Name:  ".$screen."<br>";
				echo "Followers:  ".$followers."<br>";
				echo "Friends:  ".$friends."<br>";
				echo "Tweet Time:  ".$time = $row['tweet_time'];
				echo "<br>";
				if($re_name!=" " && $re_screen!=" ")
				{	
					echo highlightkeyword("RETweetCredits", "RETweetCredits")."<br>";
					echo "Name:  ".$re_name."<br>";
					echo "Screen Name:  ".$re_screen."<br>";
				}
				echo "<br>";echo "<br>";*/
			}
			
			/// use this for printing in the html
		}
	}

$append="";
$pagenum=@$_GET["pagenum"];
$con = mysqli_connect('127.0.0.1','root','','demo');

if (!(isset($pagenum))) 
$pagenum = 1; 
//$query = "select * from tweet where id<=17";

//$data = mysqli_query($con,$query);

//$rows = mysqli_num_rows($data); 
$rows=sizeof($global4print);
$page_rows = 10;
$last = ceil($rows/$page_rows); 

if ($pagenum < 1) 
$pagenum = 1; 
elseif ($pagenum > $last) 
$pagenum = $last; 

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<body>
 <div id="header">
  Information Retrival - Project demo
   </div>
   <div id="container">
  
 
    <?php
		 
  			$global4print = array_unique($global4print);
		 for($i=0;$i<10 && ($i+($pagenum-1)*10)<sizeof($global4print);$i++)
  		{ 
  			$index=$i+(($pagenum-1)*10);
  			$con = mysqli_connect('127.0.0.1','root','','informationretrival');
			$query = "select * from tweet where id='$global4print[$index]'";
			//echo $query;
			$res = mysqli_query($con,$query);
			$row = mysqli_fetch_array($res);
			$my_id= $row['id'];
			//echo $my_id;
			$text= $row['text'];
			$name= $row['name'];
			//echo $name;
			$screen= $row['screen_name'];
			$followers= $row['followers'];
			$friends= $row['friends'];
			$re_name=$row['re_name'];
			$re_screen=$row['re_screen'];
			$time = $row['tweet_time'];
		//	if(strpos($text,$search) !== false)
			//{
 ?>
    <div id="outerBox">
   		<div id="profilePic"
        
        </div>
        <div id="content">
        	<div id="displayContent">
          <label style="color:#000000">     Name: <?php echo $name; ?></label>
           <img id="friends" src="images/friends1.png" /> &nbsp;&nbsp; <label style="color:#000000"> <?php echo $friends;   ?></label>
           <img id="follow" src="images/follower.png" /> &nbsp;&nbsp;    <label style="color:#000000"><?php echo $followers;    ?></label>
           </div>
            <div id="tweetContent">
          
                    <label style="color: #7AACF8">Tweet: </label><br>
              <?php echo  highlightkeyword($text, $search);?>
            </div>
            <?php  if($re_name!= " ") { ?>
          <label style="margin-left:200px; color:#000000">  ReTweet Credits:  <?php echo $re_name;    ?></label>
        <?php } ?></div>
   		</div>
	</div>
    <?php }
	//}
	echo "<br>";
	
    if ($pagenum == 1) 

 {

 } 

 else 

 {

 echo " <a href='{$_SERVER['PHP_SELF']}?search=$search&pagenum=1' style='color:#7DE4E5'>  <<-First</a> ";

 echo " ";

 $previous = $pagenum-1;

 echo " <a href='{$_SERVER['PHP_SELF']}?search=$search&pagenum=$previous' style='color:#7DE4E5'> <-Previous</a> ";

 }
  echo " "; echo " "; echo " ";
echo "Page: <a href='{$_SERVER['PHP_SELF']}?search=$search&pagenum=$pagenum' style='color:#2be'>$pagenum</a>....<a href='{$_SERVER['PHP_SELF']}?search=$search&pagenum=$last' style='color:#2be'>$last</a> ";
 echo " "; echo " "; echo " ";
 

if ($pagenum == $last) 
{
 } 
else {
$next = $pagenum+1;
echo " <a href='{$_SERVER['PHP_SELF']}?search=$search&pagenum=$next' style='color:#7DE4E5'>Next -></a> ";
echo " <a href='{$_SERVER['PHP_SELF']}?search=$search&pagenum=$last' style='color:#7DE4E5'>Last ->></a> ";
} ?>
	
	
	
</body>
<style>
body
{
	/*changing background color*/
    background-color:#ebebeb;
	background-image:url(images/searchBack.png);
}
#header
{
 border:thick; 
 height:70px; 
 width:auto; 
 background-color:#F64E51;
 text-align:center; 
 text-shadow:# A7E7FF; 
 color:#ffffff; 
 font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif; 
 font-size:46px;
 margin-top:5px;
}
#container
{
 border:thick; 
 height:auto; 
 width:auto;
 margin-left:10px;

 text-align:center; 
 text-shadow:# A7E7FF; 
 color:#ffffff; 
 font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif; 
 font-size:16px;
 margin-top:5px;
 padding:100px 10px 20px;
}

#outerBox
{
 border:thick; 
 height:130px; 
 width:800px;
 margin-left:300px;
 background-color: #DBF6F8;
 text-align:center; 
 text-shadow:# A7E7FF; 
 color:#ffffff; 
 font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif; 
 font-size:46px;
 margin-top:10px;
 padding:20px 10px 10px;
}

#profilePic
{
 background-image:url(images/keer.png);
 border:thick; 
 height:110px; 
 width:110px;
 padding:0px 3px 5px 5px;  
 text-align:center; 
 text-shadow:# A7E7FF; 
 color:#ffffff; 
 font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif; 
}

#content
{
 border:thick;
 margin:0px 120px;;
 height:115px; 
 width:660px;
 padding:2px 3px 0px 10px;
 text-align: left;
 font-size:16px; 
 text-shadow:# A7E7FF; 
 color:#ffffff; 
 font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif; 
}

#displayContent
{
 border:thick;
 margin-top:auto;
 height:20px; 
 width:630px;
 padding:5px 3px 2px 10px;
 text-align:left; 
 text-shadow:#A7E7FF; 
 color:#fffffff !important;
 font-size:16px;
 font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif; 
}
#friends
{
 height:20px; 
 width:20px;
 margin: auto;
 align-content:center;
  margin-left:10px;
}
#follow
{
 height:20px; 
 width:20px;
 margin: auto;
 align-content:center;
 text-align:end;
 margin-left:30px;
}
#tweetContent
{
 border:thick;
 margin-top:5px;
 height:auto; 
 width:630px;
 font-size:18px;
 padding:10px 3px 0px 10px;
 text-align:left; 
 text-shadow:# A7E7FF; 
 color:#000000; 
 font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif;
}

</style>
</html>