<?php
	$_SESSION['APP_MX'] = "mail.filmidid.com";
	$_SESSION['APP_SERVER'] = "index.php";
	$_SESSION['SITE_EMAIL'] = "email@filmidid.com";
	
	$_SESSION['LOGGEDIN'] = "";
	$_SESSION['REGNO'] = "";
	
	$_SESSION['EMAIL'] = "";
	$_SESSION['VALUE'] = '1';
	$_SESSION['SEARCH'] = "";
	$_SESSION['FNAME'] = "";
	$_SESSION['LNAME'] = "";
	
	$_SESSION['SESSION'] = true;
	
	$_SESSION['SORTBY']=false;

	$_SESSION['ERROR'] = "Default Error";
	$_SESSION['VER']= false;
	$_SESSION['EXST']= false;
	$_SESSION['DATEADDED']= 0;
	$_SESSION['POPULAR']= 0;
	$_SESSION['RATING']= 0;
	$_SESSION['POPULAR4VIDEO']= 0;
		
?>