<?php 
   session_start();
   $value=	$_SESSION['VALUE'];
	if($value=="")
	$value=1;
	$search=$_GET['key'];
	
 	
if($value==1)
{
	header("location: textSearch.php?search=$search");
}
if($value==2)
{
	header("location: nameSearch.php?search=$search");
}

if($value==3)
{
	header("location: hashtagsSearch.php?search=$search");
}
if($value==4)
{
	header("location: screenSearch.php?search=$search");
}

?>