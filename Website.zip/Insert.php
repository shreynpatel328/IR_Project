<?php
 set_time_limit(5000);

	$myfile = fopen("database_text_java_3.txt", "r") or die("Unable to open file!");
	// Output one line until end-of-file
	$k=0;
	$con = mysqli_connect('127.0.0.1','root','','informationretrival');
	while(!feof($myfile)) {
		
		
		  $query = fgets($myfile);
		 // echo $query;
		 if(trim($query) == '')
		 break;
		$onlyconsonants = str_replace("\\\"", "a\"", $query);
		//echo $onlyconsonants."<br>";
		 $res = mysqli_query($con,$onlyconsonants);
	
}

?>