
<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript">
	   function showResult(key)
	   {
	   	if(key == "" || key == " "){
	   		document.getElementById('result').innerHTML="Please Type Something";

	   	}
	   	else{
	   		var obj = new XMLHttpRequest();
	   		obj.open('GET','process.php?key='+key,true);
	   		obj.send();
            obj.onreadystatechange = function(){
            	if(obj.readyState == 4 && obj.status == 200){
            		var node= document.getElementById('result').innerHTML=obj.responseText;
					
                       	var items = node[0];
					   	for (var index in items) {
                        var li = document.createElement('li');
                        var textnode = document.createTextNode(result);
                        li.appendChild(textnode);
                        node.appendChild(li);
                    }
				}
				

            }

	   	}
	   }
	   function showResult1(key)
	   {
	   	if(key == "" || key == " "){
	   		document.getElementById('result').innerHTML="Please Type Something";

	   	}
	   	else{
	   		var obj = new XMLHttpRequest();
	   		obj.open('GET','process1.php?key='+key,true);
	   		obj.send();
            obj.onreadystatechange = function(){
            	if(obj.readyState == 4 && obj.status == 200){
            		document.getElementById('result').innerHTML=obj.responseText;
            	}

            }

	   	}
	   }
	   
	  
	</script>
	
</head>
<body>
  

   <div id="header">
  Information Retrival - Project demo
   </div>
   <form class="searchbox"  method="get" action="check.php">
         
        <input type="search" placeholder="search.." name="key" autocomplete="off" onkeyup="showResult(this.value)"/>
            <div id="space"></div>
          <a id="spacing"><input type="button" value="submit"> </a>
  		  
          <a id="spacing" onClick="showResult1(1)"><input type="button" value="text"></a>
          <a id="spacing" onClick="showResult1(2)"><input type="button" value="name"></a>
          <a id="spacing" onClick="showResult1(3)"><input type="button" value="hashtags"></a>
          <a  id="spacing" onClick="showResult1(4)"><input type="button" value="screen_name"></a>
		  
		  <a id="spacing" onClick="showResult1(5)"><input type="button" value="LUCENE"></a>
          
      
        <ul id="result">	 
        </ul> 
		
    </form>

   
<style>

body
{
	/*changing background color*/
    background-color:#ebebeb;
	background-image:url(images/10.png);
}

#pad
{
	padding:0px 390px;
}

#spacing
{
	padding:0px 3px;
}

#space
{
	padding-top:5px;
}
#header
{
 border:thick; 
 height:70px; 
 width:auto; 
 background-color:#F64E51;
 text-align:center; 
 text-shadow:# A7E7FF; 
 color:#ffffff; 
 font-family:Baskerville, "Palatino Linotype", Palatino, "Century Schoolbook L", "Times New Roman", serif; 
 font-size:46px;
 margin-top:5px;
}
.searchbox
{
/*definint width of form element*/
    width:600px;
/*centering the form element*/
    margin:50px 200px;
}
input[type="search"]{
    padding:10px 5px 10px 5px;
    font-size:30px;
    color:#0000000;
/*removing boder from search box*/
    border:none;
/*defining background image as a search symbol*/
   
    background-repeat:no-repeat;
/*background-size*/
-webkit-background-size:35px 35px;
   -moz-background-size:35px 35px;
     -o-background-size:35px 35px;
        background-size:35px 35px;
/*positioning background image*/
    background-position:8px 12px;
/*changing background color form white*/
    background-color: #F4DA6D;
}

input[type="button"]{
	
    padding:10px 5px 5px 5px;
    font-size:16px;
    color: #EC0200;
	background-color:#291CD3;
/*removing boder from search box*/
    border:thick;
/*defining background image as a search symbol*/
   
    background-repeat:no-repeat;
/*background-size*/
-webkit-background-size:35px 35px;
   -moz-background-size:35px 35px;
     -o-background-size:35px 35px;
        background-size:35px 35px;
/*positioning background image*/
    background-position:8px 12px;
/*changing background color form white*/
    background-color: #FFFFFF;
}
/*now using placeholder property to change color of placholder text and making it consitent accross the browser by use of prefix*/
input[type="search"]::-webkit-input-placeholder
{
    color:#000000;
}
input[type="search"]:-moz-placeholder 
{ 
	/* Firefox 18- */
    color: #b1e0de;
}
input[type="search"]::-moz-placeholder 
{  
	/* Firefox 19+ */
    color: #b1e0de;
}
input[type="search"]:-ms-input-placeholder 
{  
	/* interner explorer*/
    color: #b1e0de;
}


/*adding effect when the mouse is hovered over list item*/
.searchbox ul li a:hover
{
    color:#b23b61;
    background:#ecd1da;
}
/*moving it slightly toware right when hovered*/
.searchbox ul li:hover
{
/*transform*/
-webkit-transform:translateX(20px);
   -moz-transform:translateX(20px);
    -ms-transform:translateX(20px);
     -o-transform:translateX(20px);
        transform:translateX(20px);
}
/*now first we will hide the suggestion list*/

/*and make the suggestion reappear when user focus on search field*/
input[type="search"]:focus + #result
{
    height:63px;
}

.byline
{
   text-align:center;
   font-size:18px;
}
.byline a
{
   text-decoration:none;
   color: #1f5350;
}
ul
{
/*removing predefined bullet points from list*/
   list-style:none;
/*removing padding from list items*/
   padding:0px 7px;
   width:465px;
   margin-bottom:10px;
	  
/*removing underlines from anchor element*/
    text-decoration:none; 
    color:#1f5350;
    font-size:30px;
    background-color:#FFFFFF;
   
}
</style>
</body>
</html>