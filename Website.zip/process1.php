<?php
  session_start();
  $_SESSION['VALUE'] = '1';		
  $key = $_GET['key']; 
  $_SESSION['VALUE']=$key;

  //echo $_SESSION['VALUE'];
  @session_register('VALUE');
  
  
 ?>